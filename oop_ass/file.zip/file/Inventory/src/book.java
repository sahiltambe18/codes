import java.util.Scanner;

public class book {
    protected String name , author,type;
    public int price , quantity;
    public void get(){
        Scanner sc = new Scanner(System.in);
        System.out.println("enter name of book");
        name = sc.nextLine();
        System.out.println("enter author name ");
        author = sc.nextLine();
        System.out.println("enter price");
        price = sc.nextInt();
        System.out.println("quantity ");
        quantity = sc.nextInt();
    }
    public void display(){
        System.out.println(" Name : "+name+"    author : "+author+"   quantity : "+ quantity +"     price : "+price);
    }

}
