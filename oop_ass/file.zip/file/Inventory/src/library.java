import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class library extends book{
    Scanner sc = new Scanner(System.in);
    protected ArrayList<book> obj = new ArrayList<>();
    private void bubble(){
        int n = obj.size();
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n-i-1; j++) {
                if (obj.get(j).name.compareTo(obj.get(j+1).name)>0){
                    Collections.swap(obj , j , j+1);
                }
            }
        }
    }

    public int search(){
        System.out.println("enter the name of book");
        String name = sc.nextLine();
        for (int i = 0; i < obj.size(); i++) {
            if (obj.get(i).name.equals(name)){
                System.out.println("book found!!");
                obj.get(i).display();
                return i;
            }
        }
        System.out.println("book not available😣");
        return -1;
    }

    public void purchase(int n){
        System.out.println("enter quantity to purchase");
        int q = sc.nextInt();
        if (q<= obj.get(n).quantity){
            obj.get(n).quantity -=q;
            System.out.println("purchase successful");
            return;
        }else {
            System.out.println("stocks are less than your order");
        }
    }

    public void add(){
//        Scanner sc = new Scanner(System.in);
        book b = new book();
        b.get();
        obj.add(b);
        bubble();

    }
    public void display(){
        for (int i = 0 ; i < obj.size();i++){
            obj.get(i).display();
        }
    }
}
