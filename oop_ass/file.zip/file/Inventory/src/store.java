import java.io.File;
import java.util.Scanner;

public class store {
    public static void main(String[] args) {
        library l = new library();
        Scanner sc = new Scanner(System.in);
        int ch =1;
        File f = new File("output.txt");
        while (ch!=0){
            System.out.println("-------------------------------------------welcome to i2it bookstore--------------------------------------------");
            System.out.println("enter your choice  \n1.add book in store  \n2. show books \n3. purchase \n0 for exit");
            ch = sc.nextInt();
            switch (ch){
                case 1:{
                    l.add();
                    break;
                }
                case 2:{
                    l.display();
                    break;
                }
                case 3:{
                    int i =l.search();
                    l.purchase(i);
                    break;
                }
            }
        }


    }
}
