import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.Scanner;

public class opr {
    public static void main(String[] args) {
        int ch = 1;
        int n = 0;
        bank b[] = new bank[20];
        Scanner sc = new Scanner(System.in);
        try {
            File f = new File("output.txt");
            FileOutputStream fop = new FileOutputStream(f);
            ObjectOutputStream op = new ObjectOutputStream(fop);
            while (ch != 0) {
                System.out.println("-----------------------------------------CENTRAL BANK OF INDIA-----------------------------------------");
                System.out.println("1. Create a Account \n2. login into Account \n 0 for exit");
                System.out.println("-------------------------------------------------------------------------------------------------");
                System.out.println("enter your choice ");
                ch = sc.nextInt();
                switch (ch) {
                    case 1: {
                        b[n] = new bank();
                        b[n].setup();
                        Tools.bank_opr(b, n);
                        op.writeObject(b);
//                        op.flush();
                        n++;
                        break;
                    }
                    case 2: {
                        int num = Tools.login(b, n);
                        Tools.bank_opr(b, num);
                        op.writeObject(b[num]);
                    }
                }
            }
            //op.close();
            fop.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
}
