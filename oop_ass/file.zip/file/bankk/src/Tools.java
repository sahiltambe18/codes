import java.util.Scanner;

public class Tools extends bank{

    public static int login(bank b[] , int n){
        Scanner sc = new Scanner(System.in);
        System.out.println("enter the Id ");
        String id = sc.next();
        System.out.println("enter the PASSword");
        String Pass = sc.next();
        for (int i = 0; i < n; i++) {
            if (b[i].ID.equals(id) && b[i].pass.equals(Pass)){
                System.out.println("Login successful...");
                return i;
            }
        }
        System.out.println("Inva2lid Credentials !!");
        return  -1;
    }


    public static void bank_opr(bank b[] ,int n){
        if (n == -1){
            System.out.println("try again...");
            return;
        }
        Scanner sc = new Scanner(System.in);
        int ch = 1;
        while (ch!=0){
            System.out.println("enter your choice ");
            System.out.println("1. deposit money \n2. Withdraw \n3. check balance \n4. Display Account info. \n5.edit account info \n0 for exit");
            ch = sc.nextInt();
            switch (ch){
                case 1:{
                    b[n].deposit();
                    break;
                }
                case 2:{
                    b[n].withdraw();
                    break;
                }
                case 3:{
                    b[n].check();
                    break;
                }
                case 4:{
                    b[n].status();
                    break;
                }
                case 5:{
                    b[n].edit(b , n);
                    break;
                }
                case 0:{
                    b[n].limit = 40000;
                    break;
                }
            }
        }

    }

    public static void showbyidx(bank b[],int n){
        Tools.bank_opr(b , n);
    }
}
